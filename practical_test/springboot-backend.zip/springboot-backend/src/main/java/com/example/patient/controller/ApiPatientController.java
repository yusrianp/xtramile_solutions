package com.example.patient.controller;

import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;


import com.example.patient.entity.PatientEntity;
import com.example.patient.service.DeleteData;
import com.example.patient.service.GetDataPagination;
import com.example.patient.service.GetAllDataPatient;
import com.example.patient.service.GetData;
import com.example.patient.service.InsertPatient;
import com.example.patient.service.UpdatePatient;

@RestController
@RequestMapping("/api")
@CrossOrigin("*")
public class ApiPatientController {

	@Autowired
	GetDataPagination getDataPagination;
//
	@Autowired
	DeleteData deleteData;
//
	@Autowired
	InsertPatient insertPatient;

	@Autowired
	UpdatePatient updatePatient;

	@Autowired
	GetData getData;

	@Autowired
	GetAllDataPatient getAllDataPatient;

	@PostMapping("${patient_page}")
	public List<PatientEntity> MahasiswaController(@RequestBody HashMap<String, Object> parameters)
			throws SQLException {

		int first = (int) parameters.get("first");
		int last = (int) parameters.get("last");

		
		List<PatientEntity> Response = getDataPagination.GetData(first, last);

		return Response;
	}
//
	@GetMapping("${delete_patient}/{pid}")
	public HashMap<String, Object> DeleteMahasiswaController(@PathVariable("pid") String pid)
			throws SQLException {

		HashMap<String, Object> Response = new HashMap();

		Response = deleteData.deleteData(pid);

		return Response;
	}

	@PostMapping("${insert_patient}")
	public HashMap<String, Object> InsertPatientController(@RequestBody HashMap<String, Object> parameters)
			throws SQLException, ParseException {
				
		SimpleDateFormat sdf = new SimpleDateFormat("MMdd");
		SimpleDateFormat sdf2 = new SimpleDateFormat("yyyy-MM-DD");
		String date = sdf.format(new Date());
		sdf = new SimpleDateFormat("HHmmss");
		String time = sdf.format(new Date());
		String date_time = date + time;

		String pid = date_time ; 
		String first_name = (String) parameters.get("first_name");
		String last_name = (String) parameters.get("last_name");
		String dob = parameters.get("birth_date").toString().substring(0, 10);
		
	    Date dob_date = new SimpleDateFormat("yyyy-mm-DD").parse(dob);  
	    
	    Calendar cal = Calendar.getInstance();  
	    
	    cal.setTime(dob_date);
	    
        cal.add(Calendar.DAY_OF_MONTH, 1);  
        
        String dateAfter = sdf2.format(cal.getTime());  

	
		String gender = (String) parameters.get("gender");
		String address = (String) parameters.get("address");
		String suburb = (String) parameters.get("suburb");
		String state = (String) parameters.get("state");
		String postcode = (String) parameters.get("postcode");
		String phone = (String) parameters.get("phone");

		HashMap<String, Object> Response = new HashMap();

		Response = insertPatient.insertPatientData(pid, first_name, last_name, dateAfter, gender, address, suburb, state, postcode, phone);

		return Response;
	}

	@PostMapping("${update_patient}")
	public HashMap<String, Object> UpdatePatientController(@RequestBody HashMap<String, Object> parameters)
			throws SQLException {

		String pid = (String) parameters.get("pid");
		String first_name = (String) parameters.get("first_name");
		String last_name = (String) parameters.get("last_name");
		String birth_date = (String) parameters.get("birth_date");
		String gender = (String) parameters.get("gender");
		String address = (String) parameters.get("address");
		String suburb = (String) parameters.get("suburb");
		String state = (String) parameters.get("state");
		String postcode = (String) parameters.get("postcode");
		String phone = (String) parameters.get("phone");

		HashMap<String, Object> Response = new HashMap();

		Response = updatePatient.updatePatientData(pid, first_name, last_name, birth_date, gender, address, suburb, state, postcode, phone);

		return Response;
	}

	@GetMapping("${patient}/{value}")
	public List<PatientEntity> pidPatientController(@PathVariable("value") String value) throws SQLException {

		List<PatientEntity> Response = getData.GetDataValue(value);

		return Response;
	}

	@GetMapping("${patient}")
	public List<PatientEntity> patientController() throws SQLException {

		List<PatientEntity> Response = getAllDataPatient.GetDataPatient();

		return Response;
	}
	
}
