package com.example.patient.service;

import java.util.HashMap;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.patient.repository.PatientRepository;

@Service
public class UpdatePatient {
	
	@Autowired 
	PatientRepository patientRepository ;

	public HashMap<String, Object> updatePatientData(String pid, String first_name, String last_name, String birth_date, String gender, String address, String suburb, String state, String postcode, String phone){
		HashMap<String, Object> response = new HashMap() ;
		
		try {
			
			int i = patientRepository.updatePatient(first_name, last_name, birth_date, gender, address, suburb, state, postcode, phone, pid);
			
			if(i > 0) {
				response.put("rc", "00");
				response.put("rd", "success");
			}else {
				response.put("rc", "01");
				response.put("rd", "failed");
			}


		} catch (Exception e) {
			e.printStackTrace();
			response.put("rc", "99");
			response.put("rd", "error");
		}
		
		return response ; 
	}
}
