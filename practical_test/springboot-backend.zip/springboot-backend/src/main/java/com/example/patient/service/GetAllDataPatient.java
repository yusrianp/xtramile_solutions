package com.example.patient.service;

import java.util.HashMap;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.patient.entity.PatientEntity;
import com.example.patient.repository.PatientRepository;

@Service
public class GetAllDataPatient {
	
	@Autowired
	PatientRepository patientRepository ; 

	public List<PatientEntity> GetDataPatient() {
		HashMap<String, Object> Response = new HashMap() ; 
		
		try {
			
			List<PatientEntity> data = patientRepository.getPatient();
			return data ;
		} catch (Exception e) {
			e.printStackTrace();
			Response.put("rc", "99");
			Response.put("rd", "error");
			
		}
		
		return null ;
	}
}
