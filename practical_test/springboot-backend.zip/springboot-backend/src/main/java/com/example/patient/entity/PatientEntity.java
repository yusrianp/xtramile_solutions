package com.example.patient.entity;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.sql.DataSource;

import org.springframework.stereotype.Service;

import lombok.Data;

@Data
@Entity
@Table(name = "patient")
public class PatientEntity {
	@Id
	@Column(name = "pid")
	private String pid ; 
	
	@Column(name = "first_name")
	private String first_name ; 
	
	@Column(name = "last_name")
	private String last_name ; 
	
	@Column(name = "birth_date")
	private String birth_date ; 
	
	@Column(name = "gender")
	private String gender ; 
	
	@Column(name = "address")
	private String address ; 
	
	@Column(name = "suburb")
	private String suburb ; 
	
	@Column(name = "state")
	private String state ; 
	
	@Column(name = "postcode")
	private String postcode ; 
	
	@Column(name = "phone")
	private String phone ; 
	
}
