package com.example.patient.repository;

import java.util.HashMap;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.transaction.annotation.Transactional;

import com.example.patient.entity.PatientEntity;

@Transactional
public interface PatientRepository extends JpaRepository<PatientEntity, String>{
	
	@Modifying
	@Query("DELETE FROM PatientEntity WHERE pid = ?1")
	int deletePatient(String pid);
//	
	@Modifying
	@Query("UPDATE PatientEntity set first_name = ?1, last_name = ?2, birth_date = ?3, gender = ?4, address = ?5, suburb = ?6, state =?7, postcode = ?8, phone = ?9 WHERE pid = ?10")
	int updatePatient(String first_nama, String last_name, String birth_date, String gender, String address, String suburb, String sate, String postcode, String phone, String pid);

	
	@Modifying
	@Query(value = "INSERT INTO patient(first_name, last_name, birth_date, gender, address, suburb, state, postcode, phone, pid) VALUES (?1, ?2, ?3, ?4, ?5, ?6, ?7, ?8, ?9, ?10)", nativeQuery = true)
	int insertPatient(String first_name, String last_name, String birth_date, String gender, String address, String suburb, String state, String postcode, String phone, String pid);
//
	@Query(value = "SELECT * FROM patient LIMIT ?1,?2", nativeQuery = true)
	List<PatientEntity> getAllPatientPagination(int first, int last);
//	
	@Query("SELECT al FROM PatientEntity al WHERE pid = ?1 or first_name = ?1 or last_name = ?1")
	List<PatientEntity> getPatientValue(String value);
	
	@Query(value = "SELECT * FROM patient", nativeQuery = true)
	List<PatientEntity> getPatient();
	
}
